module.exports = {
  allow: [
    'hook',
    'hooks',
    'execute',
    'invalid',
    'failure',
    'cracks',
    'knives',
    'simple',
    'obvious',
    'just',
    'easy',
    'period',
    'of-course',
    'special',
    'dive',
  ],
};
