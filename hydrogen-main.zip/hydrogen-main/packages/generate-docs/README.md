# Hydrogen docs generator

Documentation generator for producing out to [shopify.dev](https://shopify.dev) from ts-doc comments and in-repo markdown files.
