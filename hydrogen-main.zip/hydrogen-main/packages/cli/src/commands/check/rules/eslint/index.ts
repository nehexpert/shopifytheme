export {checkEslintConfig} from './checkEslintConfig';
