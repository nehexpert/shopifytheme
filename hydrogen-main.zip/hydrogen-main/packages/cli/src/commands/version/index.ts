export {version as default} from './version';
