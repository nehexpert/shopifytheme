<!-- This file is generated from the source code. Edit the files in /packages/cli/src/commands/version and run 'yarn generate-docs' at the root of this repo. -->

Print the installed version of the `@shopify/hydrogen-cli`.

## Example code

```bash
h2 version
```
