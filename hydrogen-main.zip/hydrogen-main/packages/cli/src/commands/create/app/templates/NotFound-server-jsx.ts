export default function () {
  return `
  export default function NotFound() {
    return <div>NotFound component at \`src/components/NotFound.server.jsx\`</div>;
  }
  `;
}
