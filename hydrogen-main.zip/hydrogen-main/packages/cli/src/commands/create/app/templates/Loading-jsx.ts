export default function () {
  return `
  export default function Loading() {
    return <div>Loading component at \`src/components/Loading.jsx\`</div>;
  }
  `;
}
