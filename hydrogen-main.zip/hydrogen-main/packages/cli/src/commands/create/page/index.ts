export {page as default} from './page';
