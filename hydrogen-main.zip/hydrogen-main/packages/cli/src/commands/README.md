<!-- This file is generated from the source code. Edit the files in /Users/matt/src/github.com/Shopify/hydrogen/packages/cli/src/commands and run 'yarn generate-docs' at the root of this repo. -->

|                                                          |                                    |
| -------------------------------------------------------- | ---------------------------------- |
| <a href="/api/hydrogen/cli/commands/version">version</a> | Print the version of hydrogen-cli. |
