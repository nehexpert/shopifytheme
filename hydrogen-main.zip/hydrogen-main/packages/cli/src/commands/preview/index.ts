export {preview as default} from './preview';
