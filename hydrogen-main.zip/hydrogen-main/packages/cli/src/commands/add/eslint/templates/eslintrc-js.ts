export default function () {
  return `
module.exports = {
  extends: [
    'plugin:hydrogen/recommended',
  ],
};
  `;
}
