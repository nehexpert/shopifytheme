export {addShopifyConfig as default} from './shopifyConfig';
