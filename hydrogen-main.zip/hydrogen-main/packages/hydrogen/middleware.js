module.exports = require('./dist/node/framework/middleware');
