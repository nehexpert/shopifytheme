module.exports = require('./dist/node/framework/plugin');
