export {default} from './dist/esnext/entry-client';
