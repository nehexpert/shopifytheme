## Related components

- [`MediaFile`](/api/hydrogen/components/primitive/mediafile)
