## Related components

- [`Image`](/api/hydrogen/components/primitive/image)
- [`Video`](/api/hydrogen/components/primitive/video)
- [`ExternalVideo`](/api/hydrogen/components/primitive/externalvideo)
- [`ModelViewer`](/api/hydrogen/components/primitive/modelviewer)
