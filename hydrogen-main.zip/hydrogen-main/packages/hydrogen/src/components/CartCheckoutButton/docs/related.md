## Related components

- [CartProvider](/api/hydrogen/components/cart/cartprovider)

## Related hooks

- [useCart](/api/hydrogen/hooks/cart/usecart)
