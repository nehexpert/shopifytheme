## Related components

- [`CartLineProvider`](/api/hydrogen/components/cart/cartlineprovider)
- [`Image`](/api/hydrogen/components/primitive/image)
