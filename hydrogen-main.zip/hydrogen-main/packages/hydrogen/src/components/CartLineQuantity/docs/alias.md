## Alias

The `CartLineQuantity` component is aliased by the `CartLine.Quantity` component. You can use whichever component you prefer.
