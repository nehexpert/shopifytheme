## Render props

The `CartLineSelectedOptions` components provides an object with the following keys as a render prop:

| Key     | Description                       |
| ------- | --------------------------------- |
| `name`  | The name value for the attribute. |
| `value` | The value for the attribute.      |
