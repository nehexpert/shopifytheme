## Alias

The `CartLineProvider` component is aliased by the `CartLine` component. You can use whichever component you prefer.
