## Alias

The `CartLinePrice` component is aliased by the `CartLine.Price` component. You can use whichever component you prefer.
