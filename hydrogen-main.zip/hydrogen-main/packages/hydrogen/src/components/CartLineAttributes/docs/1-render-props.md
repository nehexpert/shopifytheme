## Render props

The `CartLineAttributes` components provides an object with the following keys as a render prop:

| Key     | Description                      |
| ------- | -------------------------------- |
| `key`   | The key value for the attribute. |
| `value` | The value for the attribute.     |
