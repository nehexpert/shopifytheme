## Alias

The `CartLineAttributes` component is aliased by the `CartLine.Attributes` component. You can use whichever component you prefer.
