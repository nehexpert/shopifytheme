## Alias

The `ProductDescription` component is aliased by `Product.Description`. You can use whichever component you prefer.
