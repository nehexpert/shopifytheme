## Alias

The `CartLineQuantityAdjustButton` component is aliased by the `CartLine.QuantityAdjust` component. You can use whichever component you prefer.
