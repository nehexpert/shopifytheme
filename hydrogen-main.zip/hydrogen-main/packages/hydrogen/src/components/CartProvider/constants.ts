export const CART_ID_STORAGE_KEY = 'shopifyCartId';
export const CART_COOKIE_TTL_DAYS = 14;
