// Examples of **correct** code for this rule:

// MyClientComponent.client.jsx
import {useState} from 'react';

function MyClientComponent() {
  const [state, setState] = useState();
  return null;
}
