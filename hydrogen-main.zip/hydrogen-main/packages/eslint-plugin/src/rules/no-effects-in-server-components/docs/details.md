## Rule Details

This rule prevents using these hooks in files that do not end with the `.client` suffix.
