// Examples of **incorrect** code for this rule:

function MyComponent() {
  return (
    <img src="/image.png" alt="My product image" width={300} height={300} />
  );
}
