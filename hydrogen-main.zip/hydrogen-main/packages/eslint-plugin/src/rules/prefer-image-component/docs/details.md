## Rule Details

This rule prevents using the `img` tag directly and suggests using the `Image` component from `@shopify/hydrogen`.
