## Usage

Hydrogen’s ESLint configurations come bundled in this package. To use them you must extend the relevant configuration in your project’s `.eslintrc.js`.
