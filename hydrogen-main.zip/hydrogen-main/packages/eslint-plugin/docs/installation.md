## Installation

You'll first need to install [ESLint](http://eslint.org) in addition to this module.

```bash
yarn add --dev eslint eslint-plugin-hydrogen
```
